"""Retain the fifth model and preserve the exact original four-depth sources."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root = Path(__file__).resolve().parents[2]
run = Path(__file__).resolve().parent
case = run/'cases/pursuit_l1_l4'
name = 'l1_l2_l3_l4_stateless'
metadata = json.loads((case/'summary.json').read_text())
test = json.loads((run/'quantization_l1_l4.json').read_text())
source = json.loads((root/'models'/name/'summary.json').read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert test['samples'] == source['test']['samples'] == 1194
assert test['checkpoint_epoch'] == metadata['checkpoint_epoch'] == source['best_epoch']
record = dict(variant=name,stateless_depth=4,user=10,seed=2021,
              checkpoint_epoch=test['checkpoint_epoch'],
              checkpoint_sha256=sha(root/'models'/name/'best_checkpoint.pt'),
              configuration_sha256=sha(root/'models'/name/'configuration.json'),
              source_model_directory=metadata['source'],stateless_layers=['L1','L2','L3','L4'],
              float_test=source['test'],fixed_test=test['fixed_test'],test_samples=test['samples'],
              test_cache_sha256=sha(root/'fixtures/user10/test.npz'),
              validation_cache_sha256=sha(root/'fixtures/user10/validation.npz'),
              validation_sample_indices=list(range(16)),
              validation_runtime_counters=metadata['runtime_counters'],
              independent_values_checked=metadata['independent_reference_values'],independent_mismatches=0,
              arithmetic_contract=metadata['arithmetic'],mem_sha256=metadata['mem_sha256'],
              generator_sha256=sha(root/'scripts/prepare_rtl_case.py'))
(root/'results/quantization/user10'/f'{name}.json').write_text(json.dumps(record,indent=2)+'\n')
historical = json.loads((root/'results/provenance/files.json').read_text())
selected = [r for r in historical['files'] if r.get('path')=='results/provenance/four_depth_sources.zip']
assert len(selected)==2
with zipfile.ZipFile(root/'results/provenance/four_depth_sources.zip','x',compression=zipfile.ZIP_DEFLATED) as archive:
    for item in selected:
        data = subprocess.check_output(['git','show',f'HEAD:{item["member"]}'],cwd=root)
        assert hashlib.sha256(data).hexdigest()==item['source_sha256']
        archive.writestr(item['member'],data)
print(json.dumps(dict(status='passed',model=name,fixed_test=test['fixed_test'],preserved_original_sources=2)))
